namespace MoviesAPI.Models {
    public class MoviesData {
        public int id{ get; set;}
        public string name{get; set;}
        public string genre {get; set;}
        public string duration {get; set;}
        public string releasedate {get; set;}           
    }
}